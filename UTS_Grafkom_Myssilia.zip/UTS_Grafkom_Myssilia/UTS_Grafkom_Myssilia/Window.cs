﻿using OpenTK.Windowing.Desktop;
using System;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.GraphicsLibraryFramework;
using OpenTK.Mathematics;
using LearnOpenTK.Common;

namespace UTS_Grafkom_Myssilia
{
	class Window : GameWindow
	{

		private bool firstMove = true;

		private int renderSetting = 1;

		private float cameraSpeed = 12.0f;
		private float sensitivity = 0.2f;

		private bool started = false;

		private const float BPM = 145.5f;

		private Camera camera;

		private Vector2 lastPos;

		private MyssiliaCrest myssiliaCrest;
		private ufo UFO;
		private Spaceship spaceship;

		public Window(GameWindowSettings gWS, NativeWindowSettings nWS) : base(gWS, nWS)
		{

		}

		protected override void OnLoad()
		{
			base.OnLoad();

			//User Manual
			Console.WriteLine("Controls:\nDefault WASD Controls\nSpace - Move Upwards\nShift - Move Downwards\nCtrl (Hold) - Increase Speed\n` - Switch Render Mode (Solid or Wireframe)\nF - Start Animation\nEsc - Exit Program");

			camera = new Camera(new Vector3(0, -28, 24), Size.X / (float)Size.Y);

			myssiliaCrest = new MyssiliaCrest(camera, BPM);
			UFO = new ufo(camera, BPM);
			spaceship = new Spaceship(camera, BPM);

			GL.ClearColor(0.1f, 0.1f, 0.1f, 1.0f);
			GL.Enable(EnableCap.DepthTest);

			myssiliaCrest.initObjects();
			myssiliaCrest.load();

			UFO.initObjects();
			UFO.load();

			spaceship.initObjects();
			spaceship.load();

			CursorGrabbed = true;
		}

		protected override void OnRenderFrame(FrameEventArgs args)
		{
			base.OnRenderFrame(args);

			float time = (float)args.Time;

			GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

			myssiliaCrest.render();
			UFO.render();
			spaceship.render();

			switch (myssiliaCrest.animationStage)
			{
				case 1:
					myssiliaCrest.pause(time, 128.0f);
					break;
				case 2:
					myssiliaCrest.seq1(time, 16.0f, 0);
					break;
				case 3:
					myssiliaCrest.seq1(time, 2.0f / 3.0f, 1);
					break;
				case 4:
					myssiliaCrest.seq1(time, 46.0f / 3.0f, 0);
					break;
				case 5:
					myssiliaCrest.seq2(time, 24.0f);
					break;
				case 6:
					myssiliaCrest.seq3(time, 8.0f);
					break;
				case 7:
					myssiliaCrest.seq4(time, 2.0f);
					break;
				case 8:
					myssiliaCrest.seq5(time, 5.0f / 3.0f);
					break;
				case 9:
					myssiliaCrest.seq6(time, 4.0f / 3.0f);
					break;
				case 10:
					myssiliaCrest.seq7(time, 1.0f);
					break;
				case 11:
					myssiliaCrest.pause(time, 1.0f / 3.0f);
					break;
				case 12:
					myssiliaCrest.seq8(time, 1.0f / 6.0f);
					break;
				case 13:
					myssiliaCrest.seq8(time, 1.0f / 6.0f);
					break;
				case 14:
					myssiliaCrest.seq8(time, 0);
					break;
				case 15:
					myssiliaCrest.pause(time, 2.0f / 3.0f);
					break;
				case 16:
					myssiliaCrest.seq9(time, 0);
					break;
				case 17:
					myssiliaCrest.seq10(time, 10.0f / 3.0f);
					break;
				case 18:
					myssiliaCrest.seq11(time, 1.0f, 1);
					break;
				case 19:
					myssiliaCrest.pause(time, 2.0f / 3.0f);
					break;
				case 20:
					myssiliaCrest.seq11(time, 2.0f / 3.0f, -1);
					break;
				case 21:
					myssiliaCrest.pause(time, 2.0f / 3.0f);
					break;
				case 22:
					myssiliaCrest.seq11(time, 1.0f, 1);
					break;
				case 23:
					myssiliaCrest.seq12(time, 1.0f / 3.0f, new Vector3(30, 0, 0));
					break;
				case 24:
					myssiliaCrest.seq12(time, 1.0f / 3.0f, new Vector3(-60, 0, 0));
					break;
				case 25:
					myssiliaCrest.seq12(time, 2.0f / 3.0f, new Vector3(0, 0, -30));
					break;
				case 26:
					myssiliaCrest.seq12(time, 2.0f / 3.0f, new Vector3(30, 0, 0));
					break;
				case 27:
					myssiliaCrest.seq13(time, 2.0f);
					break;
				case 28:
					myssiliaCrest.seq14(time, 5.0f / 3.0f);
					break;
				case 29:
					myssiliaCrest.seq15(time, 2.0f);
					break;
				case 30:
					myssiliaCrest.seq16(time, 2.0f);
					break;
				case 31:
					myssiliaCrest.seq17(time, 5.0f / 3.0f);
					break;
				case 32:
					myssiliaCrest.seq11(time, 1.0f, -1);
					break;
				case 33:
					myssiliaCrest.pause(time, 2.0f / 3.0f);
					break;
				case 34:
					myssiliaCrest.seq11(time, 2.0f / 3.0f, 1);
					break;
				case 35:
					myssiliaCrest.pause(time, 2.0f / 3.0f);
					break;
				case 36:
					myssiliaCrest.seq11(time, 1.0f, -1);
					break;
				case 37:
					myssiliaCrest.idle(time, 32.0f);
					break;
				case 38:
					myssiliaCrest.seq11(time, 2.0f, 1);
					break;
				case 39:
					myssiliaCrest.seq16(time, 2.0f);
					break;
				case 40:
					myssiliaCrest.seq15(time, 2.0f);
					break;
				case 41:
					myssiliaCrest.seq11(time, 2.0f, -1);
					break;
				case 42:
					myssiliaCrest.seq16(time, 8.0f);
					break;
				case 43:
					myssiliaCrest.seq11(time, 2.0f / 3.0f, 1);
					break;
				case 44:
					myssiliaCrest.seq19(time, 1.0f / 3.0f, new Vector3(-30, 0, 0));
					break;
				case 45:
					myssiliaCrest.seq19(time, 1.0f / 3.0f, new Vector3(60, 0, 0));
					break;
				case 46:
					myssiliaCrest.seq19(time, 1.0f / 3.0f, new Vector3(0, 0, -60));
					break;
				case 47:
					myssiliaCrest.seq18(time, 2.0f);
					break;
				case 48:
					myssiliaCrest.seq20(time, 2.0f / 3.0f, 1, 1);
					break;
				case 49:
					myssiliaCrest.seq20(time, 2.0f / 3.0f, 1, -1);
					break;
				case 50:
					myssiliaCrest.seq20(time, 2.0f / 3.0f, -1, 1);
					break;
				case 51:
					myssiliaCrest.seq11(time, 1.0f, 1);
					break;
				case 52:
					myssiliaCrest.seq11(time, 1.0f, -1);
					break;
				case 53:
					myssiliaCrest.seq16(time, 2.0f);
					break;
				case 54:
					myssiliaCrest.pause(time, 4.0f / 3.0f);
					break;
				case 55:
                    myssiliaCrest.seq11(time, 1.0f, 1);
                    break;
                case 56:
                    myssiliaCrest.pause(time, 2.0f / 3.0f);
                    break;
                case 57:
                    myssiliaCrest.seq11(time, 2.0f / 3.0f, -1);
                    break;
                case 58:
                    myssiliaCrest.pause(time, 2.0f / 3.0f);
                    break;
                case 59:
                    myssiliaCrest.seq11(time, 1.0f, 1);
                    break;
				case 60:
					myssiliaCrest.seq21(time, 0.0f);
					break;
				case 61:
					myssiliaCrest.idle(time, 128.0f);
					break;
			}

			switch (spaceship.animationStage)
			{
				case 1:
					spaceship.seq1(time, 64.0f);
					break;
				case 2:
					spaceship.seq2(time, 8.0f);
					break;
				case 3:
					spaceship.seq3(time, 39.0f / 6.0f);
					break;
				case 4:
					spaceship.seq4(time, 9.0f / 6.0f);
					break;
				case 5:
					spaceship.seq5(time, 12.0f);
					break;
				case 6:
					spaceship.seq6(time, 2.0f);
					break;
				case 7:
					spaceship.seq7(time, 2.0f);
					break;
				case 8:
					spaceship.seq8(time, 64.0f);
					break;
				case 9:
					spaceship.seq9(time, 8.0f);
					break;
				case 10:
					spaceship.seq10(time, 8.0f);
					break;
				case 11:
					spaceship.seq11(time, 8.0f);
					break;
				case 12:
					spaceship.seq12(time, 8.0f);
					break;
				case 13:
					spaceship.seq13(time, 32.0f);
					break;
				case 14:
					spaceship.seq14(time, 1.0f, 16);
					break;
				case 15:
					spaceship.seq14(time, 1.0f, -12);
					break;
				case 16:
					spaceship.seq15(time, 5.0f / 3.0f, 16);
					break;
				case 17:
					spaceship.seq16(time, 1.0f / 2.0f, -8, 1);
					break;
				case 18:
					spaceship.seq16(time, 1.0f / 2.0f, -8, -1);
					break;
				case 19:
					spaceship.seq16(time, 1.0f / 2.0f, 8, -1);
					break;
				case 20:
					spaceship.seq16(time, 1.0f / 2.0f, 8, 1);
					break;
				case 21:
					spaceship.seq17(time, 1.0f / 3.0f);
					break;
				case 22:
					spaceship.seq17(time, 1.0f / 3.0f);
					break;
				case 23:
					spaceship.seq17(time, 1.0f / 3.0f);
					break;
				case 24:
					spaceship.seq17(time, 1.0f / 3.0f);
					break;
				case 25:
					spaceship.seq17(time, 1.0f / 3.0f);
					break;
				case 26:
					spaceship.seq18(time, 0, 5);
					break;
				case 27:
					spaceship.seq17(time, 1.0f / 3.0f);
					break;
				case 28:
					spaceship.seq17(time, 1.0f / 3.0f);
					break;
				case 29:
					spaceship.seq17(time, 1.0f / 3.0f);
					break;
				case 30:
					spaceship.seq18(time, 0, 3);
					break;
				case 31:
					spaceship.seq14(time, 1.0f, -32);
					break;
				case 32:
					spaceship.seq19(time, 4.0f / 3.0f);
					break;
				case 33:
					spaceship.seq14(time, 1.0f, 8);
					break;
				case 34:
					spaceship.pause(time, 2.0f / 3.0f);
					break;
				case 35:
					spaceship.seq14(time, 3.0f / 3.0f, -10);
					break;
				case 36:
					spaceship.pause(time, 1.0f / 3.0f);
					break;
				case 37:
					spaceship.seq14(time, 1.0f, 12);
					break;
				case 38:
					spaceship.seq20(time, 1.0f, 20);
					break;
				case 39:
					spaceship.seq20(time, 1.0f, 20);
					break;
				case 40:
					spaceship.seq20(time, 1.0f / 3.0f, 80);
					break;
				case 41:
					spaceship.seq20(time, 1.0f / 3.0f, 70);
					break;
				case 42:
					spaceship.seq20(time, 1.0f / 3.0f, 60);
					break;
				case 43:
					spaceship.seq20(time, 1.0f / 3.0f, 50);
					break;
				case 44:
					spaceship.seq20(time, 1.0f / 3.0f, 40);
					break;
				case 45:
					spaceship.seq14(time, 2.0f, 30);
					break;
				case 46:
					spaceship.seq14(time, 1.0f, 12);
					break;
				case 47:
					spaceship.seq14(time, 1.0f, -12);
					break;
				case 48:
					spaceship.seq17(time, 1.0f / 3.0f);
					break;
				case 49:
					spaceship.seq17(time, 1.0f / 3.0f);
					break;
				case 50:
					spaceship.seq17(time, 1.0f / 3.0f);
					break;
				case 51:
					spaceship.seq17(time, 1.0f / 3.0f);
					break;
				case 52:
					spaceship.seq18(time, 0, 4);
					break;
				case 53:
					spaceship.seq14(time, 2.0f, -12);
					break;
				case 54:
					spaceship.seq14(time, 1.0f, 8);
					break;
				case 55:
					spaceship.pause(time, 2.0f / 3.0f);
					break;
				case 56:
					spaceship.seq14(time, 3.0f / 3.0f, -10);
					break;
				case 57:
					spaceship.pause(time, 1.0f / 3.0f);
					break;
				case 58:
					spaceship.seq14(time, 1.0f, 12);
					break;
				case 59:
					spaceship.seq21(time, 32.0f, 5);
					break;
				case 60:
					spaceship.seq15(time, 64.0f, 16);
					break;
				case 61:
					spaceship.seq22(time, 64.0f);
					break;
			}

			UFO.constantOn(time);

			switch (UFO.animationStage)
			{
				case 1:
					UFO.pause(time, 94.0f);
					break;
				case 2:
					UFO.seq1(time, 2.0f);
					break;
				case 3:
					UFO.seq2(time, 15.0f);
					break;
				case 4:
					UFO.seq3(time, 1.0f);
					break;
				case 5:
					UFO.seq4(time, 14.0f);
					break;
				case 6:
					UFO.seq5(time, 2.0f);
					break;
				case 7:
					UFO.seq6(time, 32.0f);
					break;
				case 8:
					UFO.seq7(time, 24.0f);
					break;
				case 9:
					UFO.seq8(time, 4.0f, 1);
					break;
				case 10:
					UFO.seq8(time, 4.0f, -1);
					break;
				case 11:
					UFO.seq9(time, 1.0f, 1);
					break;
				case 12:
					UFO.seq9(time, 1.0f, -1);
					break;
				case 13:
					UFO.seq10(time, 1.0f / 3.0f, new Vector3(10, -32, -20), 1);
					break;
				case 14:
					UFO.seq10(time, 1.0f / 3.0f, new Vector3(10, -32, -12), -1);
					break;
				case 15:
					UFO.seq10(time, 1.0f / 3.0f, new Vector3(10, -32, -4), 1);
					break;
				case 16:
					UFO.seq10(time, 1.0f / 3.0f, new Vector3(10, -32, 4), -1);
					break;
				case 17:
					UFO.seq10(time, 0, new Vector3(10, -32, 20), 1);
					break;
				case 18:
					UFO.seq11(time, 4.0f / 3.0f, 1);
					break;
				case 19:
					UFO.seq11(time, 1.0f, -1);
					break;
				case 20:
					UFO.seq12(time, 2.0f / 3.0f);
					break;
				case 21:
					UFO.seq13(time, 4.0f / 3.0f);
					break;
				case 22:
					UFO.seq14(time, 1.0f / 3.0f, new Vector3(-4, -22, 20), 1);
					break;
				case 23:
					UFO.seq14(time, 1.0f / 3.0f, new Vector3(-4, -26, 20), -1);
					break;
				case 24:
					UFO.seq14(time, 1.0f / 3.0f, new Vector3(-4, -30, 20), 1);
					break;
				case 25:
					UFO.seq14(time, 2.0f / 3.0f, new Vector3(-4, -34, 20), -1);
					break;
				case 26:
					UFO.seq15(time, 1.0f / 3.0f, new Vector3(-4, -22, 20));
					break;
				case 27:
					UFO.seq15(time, 1.0f / 3.0f, new Vector3(2, -22, 20));
					break;
				case 28:
					UFO.seq15(time, 1.0f / 3.0f, new Vector3(8, -22, 20));
					break;
				case 29:
					UFO.seq15(time, 1.0f / 3.0f, new Vector3(14, -22, 20));
					break;
				case 30:
					UFO.seq15(time, 0, new Vector3(14, -32, 20));
					break;
				case 31:
					UFO.seq16(time, 4.0f / 3.0f, 1);
					break;
				case 32:
					UFO.pause(time, 1.0f / 3.0f);
					break;
				case 33:
					UFO.seq11(time, 4.0f / 3.0f, 1);
					break;
				case 34:
					UFO.seq11(time, 1.0f, -1);
					break;
				case 35:
					UFO.seq8(time, 2.0f, 1);
					break;
				case 36:
					UFO.seq8(time, 2.0f, -1);
					break;
				case 37:
					UFO.seq11(time, 1.0f, -1);
					break;
				case 38:
					UFO.seq11(time, 1.0f, 1);
					break;
				case 39:
					UFO.seq12(time, 2.0f / 3.0f);
					break;
				case 40:
					UFO.seq13(time, 4.0f / 3.0f);
					break;
				case 41:
					UFO.seq15(time, 0, new Vector3(14, -32, 20));
					break;
				case 42:
					UFO.seq11(time, 1.0f, -1);
					break;
				case 43:
					UFO.seq11(time, 1.0f, 1);
					break;
				case 44:
					UFO.seq16(time, 4.0f / 3.0f, 1);
					break;
				case 45:
					UFO.pause(time, 1.0f / 3.0f);
					break;
				case 46:
					UFO.seq11(time, 4.0f / 3.0f, 1);
					break;
				case 47:
					UFO.pause(time, 1.0f / 3.0f);
					break;
				case 48:
					UFO.seq11(time, 4.0f / 3.0f, -1);
					break;
				case 49:
					UFO.idle(time, 64.0f);
					break;
				case 50:
					UFO.seq17(time, 32.0f, 1);
                    break;
				case 51:
					UFO.seq17(time, 32.0f, -1);
					break;
				case 52:
					UFO.pause(time, 64.0f);
					break;
			}

			SwapBuffers();
		}

		protected override void OnUpdateFrame(FrameEventArgs args)
		{
			base.OnUpdateFrame(args);

			float time = (float)args.Time;

			if (!IsFocused)
			{
				return;
			}

			var input = KeyboardState;

			if (input.IsKeyDown(Keys.Escape))
			{
				Close();
			}

			if (input.IsKeyPressed(Keys.F))
			{
				if (!started)
				{
					myssiliaCrest.animationStage = 1;
					UFO.animationStage = 1;
					spaceship.animationStage = 1;
					started = true;
				}
			}

			if (input.IsKeyDown(Keys.W))
			{
				camera.Position += Vector3.Normalize(Vector3.Cross(camera.Up, camera.Right)) * cameraSpeed * time;
			}

			if (input.IsKeyDown(Keys.S))
			{
				camera.Position -= Vector3.Normalize(Vector3.Cross(camera.Up, camera.Right)) * cameraSpeed * time;
			}

			if (input.IsKeyDown(Keys.A))
			{
				camera.Position -= camera.Right * cameraSpeed * time;
			}

			if (input.IsKeyDown(Keys.D))
			{
				camera.Position += camera.Right * cameraSpeed * time;
			}

			if (input.IsKeyDown(Keys.Space))
			{
				camera.Position += camera.Up * cameraSpeed * time;
			}

			if (input.IsKeyDown(Keys.LeftShift))
			{
				camera.Position -= camera.Up * cameraSpeed * time;
			}

			if (input.IsKeyPressed(Keys.LeftControl))
			{
				cameraSpeed += 5;
				camera.Fov += 10;
			}

			if (input.IsKeyReleased(Keys.LeftControl))
			{
				cameraSpeed -= 5;
				camera.Fov -= 10;
			}

			if (input.IsKeyPressed(Keys.GraveAccent))
			{
				renderSetting *= -1;
				myssiliaCrest.renderSetting = renderSetting;
				UFO.renderSetting = renderSetting;
				spaceship.renderSetting = renderSetting;
			}

			var mouse = MouseState;

			if (firstMove)
			{
				lastPos = new Vector2(mouse.X, mouse.Y);
				firstMove = false;
			}
			else
			{
				var deltaX = mouse.X - lastPos.X;
				var deltaY = mouse.Y - lastPos.Y;
				lastPos = new Vector2(mouse.X, mouse.Y);

				camera.Yaw += deltaX * sensitivity;
				camera.Pitch -= deltaY * sensitivity;
			}
		}

		protected override void OnResize(ResizeEventArgs e)
		{
			base.OnResize(e);

			GL.Viewport(0, 0, Size.X, Size.Y);

			camera.AspectRatio = Size.X / (float)Size.Y;
		}
	}
}
