﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LearnOpenTK.Common;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;

namespace ConsoleApp2
{
    class Asset2d
    {
        float[] vertices =
        {
            -0.5f, -0.5f, 0.0f,
            0.5f, -0.5f, 0.0f,
            0.0f, ((float)Math.Sqrt(3) / 2 - 0.5f), 0.0f
        };

        //Run2
        uint[] indices =
        {

        };

        int _vertexBufferObject;
        int _vertexArrayObject;

        //Run2
        int _elementBufferObject;

        Shader _shader;

        int index = 0;

        int[] _pascal = { };

        public Asset2d(float[] vertices, uint[] indices)
        {
            this.vertices = vertices;
            this.indices = indices;
        }

        public void load()
        {
            _vertexBufferObject = GL.GenBuffer();

            GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);

            GL.BufferData(BufferTarget.ArrayBuffer, vertices.Length * sizeof(float), vertices, BufferUsageHint.StaticDraw);

            _vertexArrayObject = GL.GenVertexArray();

            GL.BindVertexArray(_vertexArrayObject);

            //Single Color (Run1-4)
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);
            GL.EnableVertexAttribArray(0);

            //Run2
            if (indices.Length != 0)
            {
                _elementBufferObject = GL.GenBuffer();
                GL.BindBuffer(BufferTarget.ElementArrayBuffer, _elementBufferObject);
                GL.BufferData(BufferTarget.ElementArrayBuffer, indices.Length * sizeof(uint), indices, BufferUsageHint.StaticDraw);
            }

            _shader = new Shader("D:/backup/ifs4/GrafKom/C#/ConsoleApp2/ConsoleApp2/Shaders/shader.vert", "D:/backup/ifs4/GrafKom/C#/ConsoleApp2/ConsoleApp2/Shaders/shader.frag");
            _shader.Use();
        }

        public void render(int line)
        {
            _shader.Use();

            GL.BindVertexArray(_vertexArrayObject);

            if (indices.Length == 0)
            {
                if (line == 0)
                {
                    //Run1, 3, 4, 5
                    GL.DrawArrays(PrimitiveType.Triangles, 0, 3);
                }
                else if (line == 1)
                {
                    //Run1, 3, 4, 5
                    GL.DrawArrays(PrimitiveType.LineStrip, 0, 3);
                }
                else if (line == 2)
                {
                    //Run1, 3, 4, 5
                    GL.DrawArrays(PrimitiveType.LineLoop, 0, 3);
                }
                else if (line == 3)
                {
                    GL.DrawArrays(PrimitiveType.TriangleFan, 0, (vertices.Length + 1) / 3);
                }
                else if (line == 4)
                {
                    GL.DrawArrays(PrimitiveType.LineStrip, 0, index);
                }
                else if (line == 5)
                {
                    GL.DrawArrays(PrimitiveType.LineStrip, 0, (vertices.Length + 1) / 3);
                }
            }
            else
            {
                //Run2
                GL.DrawElements(PrimitiveType.Triangles, indices.Length, DrawElementsType.UnsignedInt, 0);
            }
        }
        public void createCircle(float x, float y, float r)
        {
            vertices = new float[1080];
            for (int i = 0; i < 360; i++)
            {
                double degInRad = i * Math.PI / 180;
                vertices[i * 3]     = (float)Math.Cos(degInRad) * r + x;
                vertices[i * 3 + 1] = (float)Math.Sin(degInRad) * r + y;
                vertices[i * 3 + 2] = 0;
            }
        }

        public void createEllipse(float x, float y, float a, float b)
        {
            vertices = new float[1080];
            for (int i = 0; i < 360; i++)
            {
                double degInRad = i * Math.PI / 180;
                vertices[i * 3] = (float)Math.Cos(degInRad) * a + x;
                vertices[i * 3 + 1] = (float)Math.Sin(degInRad) * b + y;
                vertices[i * 3 + 2] = 0;
            }
        }

        public void updateMousePosition(float x, float y, float z)
        {
            vertices[index * 3] = x;
            vertices[index * 3 + 1] = y;
            vertices[index * 3 + 2] = z;
            index++;

            GL.BufferData(BufferTarget.ArrayBuffer, index * 3 * sizeof(float), vertices, BufferUsageHint.StaticDraw);

            //_vertexArrayObject = GL.GenVertexArray();

            GL.BindVertexArray(_vertexArrayObject);

            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);
            GL.EnableVertexAttribArray(0);
        }

        public List<float> createCurveBezier()
        {
            List<float> vertices_bezier = new List<float>();
            List<int> pascal = getRow(index - 1);
            _pascal = pascal.ToArray();
            for (float t = 0; t <= 1.0f; t += 0.01f)
            {
                Vector2 p = getP(index, t);
                vertices_bezier.Add(p.X);
                vertices_bezier.Add(p.Y);
                vertices_bezier.Add(0);
            }
            return vertices_bezier;
        }

        public Vector2 getP(int n, float t)
        {
            Vector2 p = new Vector2(0, 0);
            float[] k = new float[n];

            for (int i = 0; i < n; i++)
            {
                k[i] = (float)Math.Pow((1 - t), n - 1 - i) * (float)Math.Pow(t, i) * _pascal[i];
            }

            for (int i = 0; i < n; i++)
            {
                p.X += k[i] * vertices[i * 3];
                p.Y += k[i] * vertices[i * 3 + 1];
            }

            return p;
        }
        
        public List<int> getRow(int rowIndex)
        {
            List<int> currentRow = new List<int>();

            currentRow.Add(1);

            if (rowIndex == 0)
            {
                return currentRow;
            }

            List<int> prev = getRow(rowIndex - 1);

            for (int i = 1; i < prev.Count; i++)
            {
                int current = prev[i - 1] + prev[i];
                currentRow.Add(current);
            }

            currentRow.Add(1);

            return currentRow;
        }

        public void setVertices(float[] vert)
        {
            vertices = vert;
        }

        public bool getVerticesLength()
        {
            if (vertices[0] == 0)
            {
                return false;
            }

            if ((vertices.Length + 1) / 3 > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
