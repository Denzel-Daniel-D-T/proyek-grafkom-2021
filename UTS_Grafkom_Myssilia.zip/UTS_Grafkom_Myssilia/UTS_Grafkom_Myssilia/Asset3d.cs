﻿using System;
using System.Collections.Generic;
using System.IO;
using LearnOpenTK.Common;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;

namespace UTS_Grafkom_Myssilia
{
	class Asset3d
	{
		private readonly string path = "D:/backup/ifs4/GrafKom/C#/UTS_Grafkom_Myssilia/UTS_Grafkom_Myssilia/Shaders/";

		private List<Vector3> vertices = new List<Vector3>();
		private List<uint> indices = new List<uint>();

		private int _vertexBufferObject;
		private int _vertexArrayObject;

		private int _elementBufferObject;

		private Shader _shader;

		private Matrix4 model = Matrix4.Identity;

		public List<Vector3> _euler = new List<Vector3>();
		public Vector3 rotationCenter = Vector3.Zero;
		public Vector3 objectCenter = Vector3.Zero;
		public Vector3 objectDimension = Vector3.Zero;

		public int groupId, rotationId;

		public Asset3d(int groupId, int rotationId)
		{
			_euler.Add(Vector3.UnitX);
			_euler.Add(Vector3.UnitY);
			_euler.Add(Vector3.UnitZ);
			this.groupId = groupId;
			this.rotationId = rotationId;
		}

		public Asset3d(Asset3d asset3D, int groupId, int rotationId)
		{
			_euler = new List<Vector3>(asset3D._euler);
			vertices = new List<Vector3>(asset3D.vertices);
			indices = new List<uint>(asset3D.indices);
			rotationCenter = new Vector3(asset3D.rotationCenter);
			objectCenter = new Vector3(asset3D.objectCenter);
			objectDimension = new Vector3(asset3D.objectDimension);
			this.groupId = groupId;
			this.rotationId = rotationId;
		}

		public void load(string fragName)
		{
			_vertexBufferObject = GL.GenBuffer();

			GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);

			GL.BufferData(BufferTarget.ArrayBuffer, vertices.Count * Vector3.SizeInBytes, vertices.ToArray(), BufferUsageHint.StaticDraw);

			_vertexArrayObject = GL.GenVertexArray();

			GL.BindVertexArray(_vertexArrayObject);

			GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 3 * sizeof(float), 0);
			GL.EnableVertexAttribArray(0);

			if (indices.Count != 0)
			{
				_elementBufferObject = GL.GenBuffer();
				GL.BindBuffer(BufferTarget.ElementArrayBuffer, _elementBufferObject);
				GL.BufferData(BufferTarget.ElementArrayBuffer, indices.Count * sizeof(uint), indices.ToArray(), BufferUsageHint.StaticDraw);
			}

			_shader = new Shader(path + "shader.vert", path + fragName + ".frag");
			_shader.Use();
		}

		public void render(int line, Matrix4 camera_view, Matrix4 camera_projection)
		{
			_shader.SetMatrix4("model", model);
			_shader.SetMatrix4("view", camera_view);
			_shader.SetMatrix4("projection", camera_projection);

			GL.BindVertexArray(_vertexArrayObject);

			if (indices.Count == 0)
			{
				if (line == 0)
				{
					GL.DrawArrays(PrimitiveType.Triangles, 0, vertices.Count);
				}
				else if (line == 1)
				{
					GL.DrawArrays(PrimitiveType.LineStrip, 0, vertices.Count);
				}
				else if (line == 2)
				{
					GL.DrawArrays(PrimitiveType.LineLoop, 0, vertices.Count);
				}
				else if (line == 3)
				{
					GL.DrawArrays(PrimitiveType.TriangleFan, 0, vertices.Count);
				}
			}
			else
			{
				if (line == 1)
				{
					GL.DrawElements(PrimitiveType.Triangles, indices.Count, DrawElementsType.UnsignedInt, 0);
				}
				else if (line == -1)
				{
					GL.DrawElements(PrimitiveType.LineStrip, indices.Count, DrawElementsType.UnsignedInt, 0);
				}
			}
		}

        #region createShapes
        public void createCuboid(float x_, float y_, float z_, float lenX, float lenY, float lenZ)
		{
			rotationCenter.X = objectCenter.X = x_;
			rotationCenter.Y = objectCenter.Y = y_;
			rotationCenter.Z = objectCenter.Z = z_;

			objectDimension.X = lenX;
			objectDimension.Y = lenY;
			objectDimension.Z = lenZ;

			Vector3 temp_vector;

			//Titik 1
			temp_vector.X = x_ - lenX / 2.0f;
			temp_vector.Y = y_ + lenY / 2.0f;
			temp_vector.Z = z_ - lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 2
			temp_vector.X = x_ + lenX / 2.0f;
			temp_vector.Y = y_ + lenY / 2.0f;
			temp_vector.Z = z_ - lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 3
			temp_vector.X = x_ - lenX / 2.0f;
			temp_vector.Y = y_ - lenY / 2.0f;
			temp_vector.Z = z_ - lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 4
			temp_vector.X = x_ + lenX / 2.0f;
			temp_vector.Y = y_ - lenY / 2.0f;
			temp_vector.Z = z_ - lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 5
			temp_vector.X = x_ - lenX / 2.0f;
			temp_vector.Y = y_ + lenY / 2.0f;
			temp_vector.Z = z_ + lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 6
			temp_vector.X = x_ + lenX / 2.0f;
			temp_vector.Y = y_ + lenY / 2.0f;
			temp_vector.Z = z_ + lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 7
			temp_vector.X = x_ - lenX / 2.0f;
			temp_vector.Y = y_ - lenY / 2.0f;
			temp_vector.Z = z_ + lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 8
			temp_vector.X = x_ + lenX / 2.0f;
			temp_vector.Y = y_ - lenY / 2.0f;
			temp_vector.Z = z_ + lenZ / 2.0f;
			vertices.Add(temp_vector);

			indices = new List<uint>
			{
				//Front
				0, 1, 2,
				1, 2, 3,
				
				//Top
				0, 4, 5,
				0, 1, 5,

				//Right
				1, 3, 5,
				3, 5, 7,

				//Left
				0, 2, 4,
				2, 4, 6,

				//Back
				4, 5, 6,
				5, 6, 7,

				//Bottom
				2, 3, 6,
				3, 6 ,7
			};
		}

		public void createRhombicPrism(float x_, float y_, float z_, float lenX, float lenY, float lenZ)
		{
			rotationCenter.X = objectCenter.X = x_;
			rotationCenter.Y = objectCenter.Y = y_;
			rotationCenter.Z = objectCenter.Z = z_;

			objectDimension.X = lenX;
			objectDimension.Y = lenY;
			objectDimension.Z = lenZ;

			Vector3 temp_vector;

			//Titik 1
			temp_vector.X = x_ - lenX / 2.0f;
			temp_vector.Y = y_;
			temp_vector.Z = z_ - lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 2
			temp_vector.X = x_;
			temp_vector.Y = y_ + lenY / 2.0f;
			temp_vector.Z = z_ - lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 3
			temp_vector.X = x_;
			temp_vector.Y = y_ - lenY / 2.0f;
			temp_vector.Z = z_ - lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 4
			temp_vector.X = x_ + lenX / 2.0f;
			temp_vector.Y = y_;
			temp_vector.Z = z_ - lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 5
			temp_vector.X = x_ - lenX / 2.0f;
			temp_vector.Y = y_;
			temp_vector.Z = z_ + lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 6
			temp_vector.X = x_;
			temp_vector.Y = y_ + lenY / 2.0f;
			temp_vector.Z = z_ + lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 7
			temp_vector.X = x_;
			temp_vector.Y = y_ - lenY / 2.0f;
			temp_vector.Z = z_ + lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 8
			temp_vector.X = x_ + lenX / 2.0f;
			temp_vector.Y = y_;
			temp_vector.Z = z_ + lenZ / 2.0f;
			vertices.Add(temp_vector);

			indices = new List<uint>
			{
				//Front
				0, 1, 2,
				1, 2, 3,
				
				//Top
				0, 4, 5,
				0, 1, 5,

				//Right
				1, 3, 5,
				3, 5, 7,

				//Left
				0, 2, 4,
				2, 4, 6,

				//Back
				4, 5, 6,
				5, 6, 7,

				//Bottom
				2, 3, 6,
				3, 6 ,7
			};
		}

		public void createTrapezoidPrism(float x_, float y_, float z_, float lenX, float lenY, float lenZ, float angleMinX, float anglePosX)
		{
			rotationCenter.X = objectCenter.X = x_;
			rotationCenter.Y = objectCenter.Y = y_;
			rotationCenter.Z = objectCenter.Z = z_;

			objectDimension.X = lenX;
			objectDimension.Y = lenY;
			objectDimension.Z = lenZ;

			Vector3 temp_vector;

			//Titik 1
			temp_vector.X = x_ - lenX / 2.0f;
			temp_vector.Y = y_ + lenY / 2.0f;
			temp_vector.Z = z_ - lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 2
			temp_vector.X = x_ + lenX / 2.0f;
			temp_vector.Y = y_ + lenY / 2.0f;
			temp_vector.Z = z_ - lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 3
			temp_vector.X = x_ - (lenX + (float)Math.Tan(angleMinX) * lenY * 2) / 2.0f;
			temp_vector.Y = y_ - lenY / 2.0f;
			temp_vector.Z = z_ - lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 4
			temp_vector.X = x_ + (lenX + (float)Math.Tan(anglePosX) * lenY * 2) / 2.0f;
			temp_vector.Y = y_ - lenY / 2.0f;
			temp_vector.Z = z_ - lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 5
			temp_vector.X = x_ - lenX / 2.0f;
			temp_vector.Y = y_ + lenY / 2.0f;
			temp_vector.Z = z_ + lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 6
			temp_vector.X = x_ + lenX / 2.0f;
			temp_vector.Y = y_ + lenY / 2.0f;
			temp_vector.Z = z_ + lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 7
			temp_vector.X = x_ - (lenX + (float)Math.Tan(angleMinX) * lenY * 2) / 2.0f;
			temp_vector.Y = y_ - lenY / 2.0f;
			temp_vector.Z = z_ + lenZ / 2.0f;
			vertices.Add(temp_vector);

			//Titik 8
			temp_vector.X = x_ + (lenX + (float)Math.Tan(anglePosX) * lenY * 2) / 2.0f;
			temp_vector.Y = y_ - lenY / 2.0f;
			temp_vector.Z = z_ + lenZ / 2.0f;
			vertices.Add(temp_vector);

			indices = new List<uint>
			{
				//Front
				0, 1, 2,
				1, 2, 3,
				
				//Top
				0, 4, 5,
				0, 1, 5,

				//Right
				1, 3, 5,
				3, 5, 7,

				//Left
				0, 2, 4,
				2, 4, 6,

				//Back
				4, 5, 6,
				5, 6, 7,

				//Bottom
				2, 3, 6,
				3, 6 ,7
			};
		}

		public void createEllipsoid(float x_, float y_, float z_, float radX, float radY, float radZ, int sectorCount, int stackCount)
		{
			rotationCenter.X = objectCenter.X = x_;
			rotationCenter.Y = objectCenter.Y = y_;
			rotationCenter.Z = objectCenter.Z = z_;

			float pi = (float)Math.PI;
			Vector3 temp_vector;
			float sectorStep = 2 * pi / sectorCount;
			float stackStep = pi / stackCount;
			float sectorAngle, stackAngle, x, y, z;

			for (int i = 0; i <= stackCount; ++i)
			{
				stackAngle = pi / 2 - i * stackStep;
				x = radX * (float)Math.Cos(stackAngle);
				y = radY * (float)Math.Sin(stackAngle);
				z = radZ * (float)Math.Cos(stackAngle);

				for (int j = 0; j <= sectorCount; ++j)
				{
					sectorAngle = j * sectorStep;

					temp_vector.X = x_ + x * (float)Math.Cos(sectorAngle);
					temp_vector.Y = y_ + y;
					temp_vector.Z = z_ + z * (float)Math.Sin(sectorAngle);

					vertices.Add(temp_vector);
				}
			}

			uint k1, k2;
			for (int i = 0; i < stackCount; ++i)
			{
				k1 = (uint)(i * (sectorCount + 1));
				k2 = (uint)(k1 + sectorCount + 1);

				for (int j = 0; j < sectorCount; ++j, ++k1, ++k2)
				{
					if (i != 0)
					{
						indices.Add(k1);
						indices.Add(k2);
						indices.Add(k1 + 1);

					}

					if (i != stackCount - 1)
					{
						indices.Add(k1 + 1);
						indices.Add(k2);
						indices.Add(k2 + 1);
					}
				}
			}
		}

		public void createFractionedEllipsoid(float x_, float y_, float z_, float radX, float radY, float radZ, int sectorCount, int stackCount, float fraction, float startPoint = 0)
		{
			rotationCenter.X = objectCenter.X = x_;
			rotationCenter.Y = objectCenter.Y = y_;
			rotationCenter.Z = objectCenter.Z = z_;

			objectDimension.X = radX * 2;
			objectDimension.Y = radY * 2;
			objectDimension.Z = radZ * 2;

			float pi = (float)Math.PI;
			Vector3 temp_vector;
			float sectorStep = 2 * pi / sectorCount;
			float stackStep = pi / stackCount;
			float sectorAngle, stackAngle, x, y, z;
			int fractionedStack = (int)(stackCount * fraction);
			int fractionedStart = (int)(stackCount * startPoint);

			for (int i = fractionedStart; i <= fractionedStack; ++i)
			{
				stackAngle = pi / 2 - i * stackStep;
				x = radX * (float)Math.Cos(stackAngle);
				y = radY * (float)Math.Sin(stackAngle);
				z = radZ * (float)Math.Cos(stackAngle);

				for (int j = 0; j <= sectorCount; ++j)
				{
					sectorAngle = j * sectorStep;

					temp_vector.X = x_ + x * (float)Math.Cos(sectorAngle);
					temp_vector.Y = y_ + y;
					temp_vector.Z = z_ + z * (float)Math.Sin(sectorAngle);

					vertices.Add(temp_vector);
				}
			}

			uint k1, k2;
			for (int i = 0; i < fractionedStack - fractionedStart; ++i)
			{
				k1 = (uint)(i * (sectorCount + 1));
				k2 = (uint)(k1 + sectorCount + 1);

				for (int j = 0; j < sectorCount; ++j, ++k1, ++k2)
				{
					if (fractionedStart == 0)
					{
						if (i != 0)
						{
							indices.Add(k1);
							indices.Add(k2);
							indices.Add(k1 + 1);
						}
					}
					else
					{
						indices.Add(k1);
						indices.Add(k2);
						indices.Add(k1 + 1);
					}

					if (i != stackCount - 1)
					{
						indices.Add(k1 + 1);
						indices.Add(k2);
						indices.Add(k2 + 1);
					}
				}
			}
		}

		public void createEllipticCone(float x_, float y_, float z_, float radX, float height, float radZ, int sectorCount, int stackCount)
		{
			rotationCenter.X = objectCenter.X = x_;
			rotationCenter.Y = objectCenter.Y = y_;
			rotationCenter.Z = objectCenter.Z = z_;

			objectDimension.X = radX;
			objectDimension.Y = height;
			objectDimension.Z = radZ;

			float pi = (float)Math.PI;
			Vector3 temp_vector;
			float sectorStep = 2 * pi / sectorCount;
			float sectorAngle, x, y, z;

			for (int i = 0; i <= sectorCount; ++i)
			{
				vertices.Add(new Vector3(x_, y_ - height / 2, z_));
			}
			for (int i = 0; i <= stackCount; ++i)
			{
				x = radX * (stackCount - i) / stackCount;
				y = height * i / stackCount - height / 2;
				z = radZ * (stackCount - i) / stackCount;

				for (int j = 0; j <= sectorCount; ++j)
				{
					sectorAngle = j * sectorStep;

					temp_vector.X = x_ + x * (float)Math.Cos(sectorAngle);
					temp_vector.Y = y_ + y;
					temp_vector.Z = z_ + z * (float)Math.Sin(sectorAngle);

					vertices.Add(temp_vector);
				}
			}

			uint k1, k2;
			int newStackCount = stackCount + 1;
			for (int i = 0; i < newStackCount; ++i)
			{
				k1 = (uint)(i * (sectorCount + 1));
				k2 = (uint)(k1 + sectorCount + 1);

				for (int j = 0; j < sectorCount; ++j, ++k1, ++k2)
				{
					if (i != 0)
					{
						indices.Add(k1);
						indices.Add(k2);
						indices.Add(k1 + 1);
					}
					if (i != newStackCount - 1)
					{
						indices.Add(k1 + 1);
						indices.Add(k2);
						indices.Add(k2 + 1);
					}
				}
			}
		}

		public void createSinusoidCapsule(float x_, float y_, float z_, float radX, float radY, float radZ, int sectorCount, int stackCount)
		{
			rotationCenter.X = objectCenter.X = x_;
			rotationCenter.Y = objectCenter.Y = y_;
			rotationCenter.Z = objectCenter.Z = z_;

			float pi = (float)Math.PI;
			Vector3 temp_vector;
			float sectorStep = 2 * pi / sectorCount;
			float stackStep = pi / stackCount;
			float sectorAngle, stackAngle, x, y, z;

			for (int i = 0; i <= stackCount; ++i)
			{
				stackAngle = pi / 2 - i * stackStep;
				x = radX * (float)Math.Cos(stackAngle);
				y = 2 * radY * i / stackCount;
				z = radZ * (float)Math.Cos(stackAngle);

				for (int j = 0; j <= sectorCount; ++j)
				{
					sectorAngle = j * sectorStep;

					temp_vector.X = x_ + x * (float)Math.Cos(sectorAngle);
					temp_vector.Y = y_ + y;
					temp_vector.Z = z_ + z * (float)Math.Sin(sectorAngle);

					vertices.Add(temp_vector);
				}
			}

			uint k1, k2;
			for (int i = 0; i < stackCount; ++i)
			{
				k1 = (uint)(i * (sectorCount + 1));
				k2 = (uint)(k1 + sectorCount + 1);

				for (int j = 0; j < sectorCount; ++j, ++k1, ++k2)
				{
					if (i != 0)
					{
						indices.Add(k1);
						indices.Add(k2);
						indices.Add(k1 + 1);

					}

					if (i != stackCount - 1)
					{
						indices.Add(k1 + 1);
						indices.Add(k2);
						indices.Add(k2 + 1);
					}
				}
			}
		}

		public void createCylinder(float x_, float y_, float z_, float radX, float height, float radZ, int sectorCount, int stackCount)
		{
			rotationCenter.X = objectCenter.X = x_;
			rotationCenter.Y = objectCenter.Y = y_;
			rotationCenter.Z = objectCenter.Z = z_;

			objectDimension.X = radX * 2;
			objectDimension.Y = height;
			objectDimension.Z = radZ * 2;

			float pi = (float)Math.PI;
			Vector3 temp_vector;
			float sectorStep = 2 * pi / sectorCount;
			float sectorAngle, x, y, z;

			for (int j = 0; j <= sectorCount; ++j)
			{
				vertices.Add(new Vector3(x_, y_ - height / 2, z_));
			}

			for (int i = 0; i <= stackCount; ++i)
			{
				x = radX;
				y = height * i / stackCount - height / 2;
				z = radZ;
				for (int j = 0; j <= sectorCount; ++j)
				{
					sectorAngle = j * sectorStep;

					temp_vector.X = x_ + x * (float)Math.Cos(sectorAngle);
					temp_vector.Y = y_ + y;
					temp_vector.Z = z_ + z * (float)Math.Sin(sectorAngle);

					vertices.Add(temp_vector);
				}
			}

			for (int j = 0; j <= sectorCount; ++j)
			{
				vertices.Add(new Vector3(x_, y_ + height / 2, z_));
			}

			uint k1, k2;
			int newStackCount = stackCount + 2;
			for (int i = 0; i < newStackCount; ++i)
			{
				k1 = (uint)(i * (sectorCount + 1));
				k2 = (uint)(k1 + sectorCount + 1);

				for (int j = 0; j < sectorCount; ++j, ++k1, ++k2)
				{
					if (i != 0)
					{
						indices.Add(k1);
						indices.Add(k2);
						indices.Add(k1 + 1);

					}

					if (i != newStackCount - 1)
					{
						indices.Add(k1 + 1);
						indices.Add(k2);
						indices.Add(k2 + 1);
					}
				}
			}
		}

		public void createVariedCylinder(float x_, float y_, float z_, float height, float topRad, float botRad, int sectorCount, int stackCount, bool isTopFilled, bool isBottomFilled)
		{
			rotationCenter.X = objectCenter.X = x_;
			rotationCenter.Y = objectCenter.Y = y_;
			rotationCenter.Z = objectCenter.Z = z_;

			float pi = (float)Math.PI;
			Vector3 temp_vector;
			float sectorStep = 2 * pi / sectorCount;
			float sectorAngle, x, y, z;
			int newStackCount = stackCount;

			if (isBottomFilled)
			{
				for (int j = 0; j <= sectorCount; ++j)
				{
					vertices.Add(new Vector3(x_, y_ - height / 2, z_));
				}
				newStackCount++;
			}

			for (int i = 0; i <= stackCount; ++i)
			{
				x = z = botRad + i * (topRad - botRad) / stackCount;
				y = height * i / stackCount - height / 2;
				for (int j = 0; j <= sectorCount; ++j)
				{
					sectorAngle = j * sectorStep;

					temp_vector.X = x_ + x * (float)Math.Cos(sectorAngle);
					temp_vector.Y = y_ + y;
					temp_vector.Z = z_ + z * (float)Math.Sin(sectorAngle);

					vertices.Add(temp_vector);
				}
			}

			if (isTopFilled)
			{
				for (int j = 0; j <= sectorCount; ++j)
				{
					vertices.Add(new Vector3(x_, y_ + height / 2, z_));
				}
				newStackCount++;
			}

			uint k1, k2;
			for (int i = 0; i < newStackCount; ++i)
			{
				k1 = (uint)(i * (sectorCount + 1));
				k2 = (uint)(k1 + sectorCount + 1);

				for (int j = 0; j < sectorCount; ++j, ++k1, ++k2)
				{
					if (i != 0 || !isBottomFilled)
					{
						indices.Add(k1);
						indices.Add(k2);
						indices.Add(k1 + 1);
					}

					if (i != newStackCount - 1 || !isTopFilled)
					{
						indices.Add(k1 + 1);
						indices.Add(k2);
						indices.Add(k2 + 1);
					}
				}
			}
		}

		public void createEllipticParaboloid(float x_, float y_, float z_, float radX, float height, float radZ, int sectorCount, int stackCount)
		{
			rotationCenter.X = objectCenter.X = x_;
			rotationCenter.Y = objectCenter.Y = y_;
			rotationCenter.Z = objectCenter.Z = z_;

			objectDimension.X = radX * 2;
			objectDimension.Y = height;
			objectDimension.Z = radZ * 2;

			height = MathF.Sqrt(height * 2);

			float pi = (float)Math.PI;
			Vector3 temp_vector;
			float sectorStep = 2 * pi / sectorCount;
			float stackStep = height * 2 / (2 * stackCount);
			float sectorAngle, stackAngle, x, y, z;

			for (int i = 0; i <= stackCount; ++i)
			{
				stackAngle = height - i * stackStep;
				x = radX * stackAngle;
				y = stackAngle * stackAngle;
				z = radZ * stackAngle;

				for (int j = 0; j <= sectorCount; ++j)
				{
					sectorAngle = j * sectorStep;

					temp_vector.X = x_ + x * (float)Math.Cos(sectorAngle);
					temp_vector.Y = y_ + y;
					temp_vector.Z = z_ + z * (float)Math.Sin(sectorAngle);

					vertices.Add(temp_vector);
				}
			}

			uint k1, k2;
			for (int i = 0; i < stackCount; ++i)
			{
				k1 = (uint)(i * (sectorCount + 1));
				k2 = (uint)(k1 + sectorCount + 1);

				for (int j = 0; j < sectorCount; ++j, ++k1, ++k2)
				{
					indices.Add(k1);
					indices.Add(k2);
					indices.Add(k1 + 1);

					if (i != stackCount - 1)
					{
						indices.Add(k1 + 1);
						indices.Add(k2);
						indices.Add(k2 + 1);
					}
				}
			}
		}

		public void createCircle(float x_, float y_, float z_, float radX, float radZ, float sectorCount)
		{
			rotationCenter.X = objectCenter.X = x_;
			rotationCenter.Y = objectCenter.Y = y_;
			rotationCenter.Z = objectCenter.Z = z_;

			objectDimension.X = radX * 2;
			objectDimension.Y = 0;
			objectDimension.Z = radZ * 2;

			float pi = (float)Math.PI;
			Vector3 temp_vector;
			float sectorStep = 2 * pi / sectorCount;
			float sectorAngle;

			for (int j = 0; j <= sectorCount; ++j)
			{
				vertices.Add(new Vector3(x_, y_, z_));
			}

			for (int j = 0; j <= sectorCount; ++j)
			{
				sectorAngle = j * sectorStep;

				temp_vector.X = x_ + radX * (float)Math.Cos(sectorAngle);
				temp_vector.Y = y_;
				temp_vector.Z = z_ + radZ * (float)Math.Sin(sectorAngle);

				vertices.Add(temp_vector);
			}

			uint k1, k2;
			k1 = 0;
			k2 = (uint)(sectorCount + 1);

			for (int j = 0; j < sectorCount; ++j, ++k1, ++k2)
			{
				indices.Add(k1);
				indices.Add(k2);
				indices.Add(k2 + 1);
			}
		}
        #endregion

        public void rotate(Vector3 pivot, Vector3 vector, float angle)
		{
			angle = MathHelper.DegreesToRadians(angle);

			for (int i = 0; i < vertices.Count; i++)
			{
				vertices[i] = getRotationResult(pivot, vector, angle, vertices[i]);
			}

			for (int i = 0; i < 3; i++)
			{
				_euler[i] = getRotationResult(pivot, vector, angle, _euler[i], true);
				float length = (float)Math.Sqrt(Math.Pow(_euler[i].X, 2.0f) + Math.Pow(_euler[i].Y, 2.0f) + Math.Pow(_euler[i].Z, 2.0f));
				Vector3 temp = new Vector3(0, 0, 0);
				temp.X = _euler[i].X / length;
				temp.Y = _euler[i].Y / length;
				temp.Z = _euler[i].Z / length;
				_euler[i] = temp;
			}
			rotationCenter = getRotationResult(pivot, vector, angle, rotationCenter);
			objectCenter = getRotationResult(pivot, vector, angle, objectCenter);

			GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);
			GL.BufferData(BufferTarget.ArrayBuffer, vertices.Count * Vector3.SizeInBytes, vertices.ToArray(), BufferUsageHint.StaticDraw);
		}

		public Vector3 getRotationResult(Vector3 pivot, Vector3 vector, float angle, Vector3 point, bool isEuler = false)
		{
			Vector3 temp, newPosition;

			if (isEuler)
			{
				temp = point;
			}
			else
			{
				temp = point - pivot;
			}

			newPosition.X =
				temp.X * (float)(Math.Cos(angle) + Math.Pow(vector.X, 2.0f) * (1.0f - Math.Cos(angle))) +
				temp.Y * (float)(vector.X * vector.Y * (1.0f - Math.Cos(angle)) - vector.Z * Math.Sin(angle)) +
				temp.Z * (float)(vector.X * vector.Z * (1.0f - Math.Cos(angle)) + vector.Y * Math.Sin(angle));

			newPosition.Y =
				temp.X * (float)(vector.X * vector.Y * (1.0f - Math.Cos(angle)) + vector.Z * Math.Sin(angle)) +
				temp.Y * (float)(Math.Cos(angle) + Math.Pow(vector.Y, 2.0f) * (1.0f - Math.Cos(angle))) +
				temp.Z * (float)(vector.Y * vector.Z * (1.0f - Math.Cos(angle)) - vector.X * Math.Sin(angle));

			newPosition.Z =
				temp.X * (float)(vector.X * vector.Z * (1.0f - Math.Cos(angle)) - vector.Y * Math.Sin(angle)) +
				temp.Y * (float)(vector.Y * vector.Z * (1.0f - Math.Cos(angle)) + vector.X * Math.Sin(angle)) +
				temp.Z * (float)(Math.Cos(angle) + Math.Pow(vector.Z, 2.0f) * (1.0f - Math.Cos(angle)));

			if (isEuler)
			{
				temp = newPosition;
			}
			else
			{
				temp = newPosition + pivot;
			}
			return temp;
		}

		public void resetEuler()
		{
			_euler[0] = Vector3.UnitX;
			_euler[1] = Vector3.UnitY;
			_euler[2] = Vector3.UnitZ;
		}

		public void translate(float x, float y, float z)
		{
			objectCenter.X += x;
			objectCenter.Y += y;
			objectCenter.Z += z;

			rotationCenter.X += x;
			rotationCenter.Y += y;
			rotationCenter.Z += z;

			var temp = new List<Vector3>();
			foreach (Vector3 i in vertices)
			{
				var tempVector = new Vector3(i.X + x, i.Y + y, i.Z + z);
				temp.Add(tempVector);
			}
			vertices = temp;

			GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);
			GL.BufferData(BufferTarget.ArrayBuffer, vertices.Count * Vector3.SizeInBytes, vertices.ToArray(), BufferUsageHint.StaticDraw);
		}

		public void mirrorX(float x)
		{
			objectCenter.X = 2 * x - objectCenter.X;

			rotationCenter.X = 2 * x - rotationCenter.X;

			var temp = new List<Vector3>();
			foreach (Vector3 i in vertices)
			{
				var tempVector = new Vector3(0, i.Y, i.Z);
				if (i.X != x)
				{
					tempVector.X = 2 * x - i.X;
				}
				else
				{
					tempVector.X = i.X;
				}
				temp.Add(tempVector);
			}
			vertices = temp;
		}

		public void mirrorY(float y)
		{
			objectCenter.Y = 2 * y - objectCenter.Y;

			rotationCenter.Y = 2 * y - rotationCenter.Y;

			var temp = new List<Vector3>();
			foreach (Vector3 i in vertices)
			{
				var tempVector = new Vector3(i.X, 0, i.Z);
				if (i.Y != y)
				{
					tempVector.Y = 2 * y - i.Y;
				}
				else
				{
					tempVector.Y = i.Y;
				}
				temp.Add(tempVector);
			}
			vertices = temp;
		}

		public void scaleLocal(float scaleX, float scaleY, float scaleZ)
		{
			var temp = new List<Vector3>();
			foreach (Vector3 i in vertices)
			{
				var tempVector = new Vector3((i.X - objectCenter.X) * scaleX + objectCenter.X, (i.Y - objectCenter.Y) * scaleY + objectCenter.Y, (i.Z - objectCenter.Z) * scaleZ + objectCenter.Z);
				temp.Add(tempVector);
			}
			vertices = temp;

			objectDimension.X *= scaleX;
			objectDimension.Y *= scaleY;
			objectDimension.Z *= scaleZ;

			GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);
			GL.BufferData(BufferTarget.ArrayBuffer, vertices.Count * Vector3.SizeInBytes, vertices.ToArray(), BufferUsageHint.StaticDraw);
		}

		public void scale(Vector3 centerPoint, float scaleX, float scaleY, float scaleZ)
		{
			var temp = new List<Vector3>();
			foreach (Vector3 i in vertices)
			{
				var tempVector = new Vector3((i.X - centerPoint.X) * scaleX + centerPoint.X, (i.Y - centerPoint.Y) * scaleY + centerPoint.Y, (i.Z - centerPoint.Z) * scaleZ + centerPoint.Z);
				temp.Add(tempVector);
			}
			vertices = temp;

			var tempX = centerPoint.X - objectCenter.X;
			var tempY = centerPoint.Y - objectCenter.Y;
			var tempZ = centerPoint.Z - objectCenter.Z;

			objectCenter.X = objectCenter.X + tempX * (1 - scaleX);
			objectCenter.Y = objectCenter.Y + tempY * (1 - scaleY);
			objectCenter.Z = objectCenter.Z + tempZ * (1 - scaleZ);

			objectDimension.X *= scaleX;
			objectDimension.Y *= scaleY;
			objectDimension.Z *= scaleZ;

			GL.BindBuffer(BufferTarget.ArrayBuffer, _vertexBufferObject);
			GL.BufferData(BufferTarget.ArrayBuffer, vertices.Count * Vector3.SizeInBytes, vertices.ToArray(), BufferUsageHint.StaticDraw);
		}
	}
}
